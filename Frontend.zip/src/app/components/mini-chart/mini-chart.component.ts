import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ChartComponent,
  NgApexchartsModule,
  ApexChart,
  ApexAxisChartSeries,
  ApexXAxis,
  ApexStroke,
  ApexTooltip,
  ApexDataLabels,
  ApexYAxis
} from 'ng-apexcharts';

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  stroke: ApexStroke;
  tooltip: ApexTooltip;
  dataLabels: ApexDataLabels;
  yaxis: ApexYAxis;
};

@Component({
  selector: 'app-mini-chart',
  standalone: true,
  imports: [CommonModule, NgApexchartsModule],
  templateUrl: './mini-chart.component.html',
  styleUrl: './mini-chart.component.scss'
})
export class MiniChartComponent implements OnChanges {
  @Input() prices: number[] = [];

  chartOptions!: Partial<ChartOptions>;

  ngOnChanges(): void {
    this.updateChart();
  }

  updateChart() {
    this.chartOptions = {
      series: [
        {
          name: 'Price',
          data: this.prices
        }
      ],
      chart: {
        type: 'line',
        height: 160,
        sparkline: {
          enabled: true
        }
      },
      stroke: {
        curve: 'smooth',
        width: 2
      },
      tooltip: {
        enabled: true
      },
      dataLabels: {
        enabled: false
      },
      xaxis: {
        type: 'numeric',
        labels: {
          show: false
        }
      },
      yaxis: {
        show: false
      }
    };
  }
}
