import { Component } from '@angular/core';

@Component({
  selector: 'app-serach-bar',
  standalone: true,
  imports: [],
  templateUrl: './serach-bar.component.html',
  styleUrl: './serach-bar.component.scss'
})
export class SerachBarComponent {

}
