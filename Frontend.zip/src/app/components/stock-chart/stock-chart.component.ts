import { Component } from '@angular/core';

@Component({
  selector: 'app-stock-chart',
  standalone: true,
  imports: [],
  templateUrl: './stock-chart.component.html',
  styleUrl: './stock-chart.component.scss'
})
export class StockChartComponent {

}
