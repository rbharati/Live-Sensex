import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { WebsocketService } from '../../services/websocket.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent implements OnInit {


  appTitle = 'LiveStocks';
  searchTerm = '';
  isDarkTheme=true;
  sensex:number=0;
  nifty:number=0;
    sensexData = signal<any[]>([]);

    private socketSubscription!: Subscription;

  @Output() searchChanged = new EventEmitter<string>();
    constructor(private marketSocketService: WebsocketService) {}


  ngOnInit():void{
console.log("heer")
      this.socketSubscription = this.marketSocketService.listen('indices_update')
      .subscribe((data) => {
            console.log('Received WebSocket data in Navbar:', data);

        this.sensexData.set(data);  // live update
      });
  
    

  }
  toggleTheme(): void {
    this.isDarkTheme = !this.isDarkTheme;
    const theme = this.isDarkTheme ? 'dark' : 'light';
    document.body.classList.toggle('dark-theme', this.isDarkTheme);
    localStorage.setItem('theme', theme);
  }
  topStocks = [
    { symbol: 'AAPL', price: 202.5, change: 0.5 },
    // { symbol: 'GOOGL', price: 2700.5, change: 0.3 },
    // { symbol: 'MSFT', price: 300.78, change: -1.2 },
  ];

  onSearchChange() {
    this.searchChanged.emit(this.searchTerm);
  }
  ngOnDestroy(): void {
    this.socketSubscription?.unsubscribe();
  }
  
}
