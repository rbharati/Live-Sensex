import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ServicesTsService } from '../../services/services.ts.service';
import { Stock } from '../../models/model';
import { CommonModule } from '@angular/common';
import { MiniChartComponent } from '../mini-chart/mini-chart.component';

@Component({
  selector: 'app-stock-list',
  standalone: true,
  imports: [CommonModule,MiniChartComponent],
  templateUrl: './stock-list.component.html',
  styleUrl: './stock-list.component.scss'
})
export class StockListComponent {

    @Input() searchTerm = '';
  @Output() stockSelected = new EventEmitter<Stock>();

  stocks: Stock[] = [];

  constructor(private stockService: ServicesTsService) {
this.stockService.getStocks().subscribe((data: Stock[]) => {
      this.stocks = data;
    });  }

  get filteredStocks(): Stock[] {
    const term = this.searchTerm.toLowerCase().trim();
    return this.stocks.filter(stock =>
      stock.Company.toLowerCase().includes(term) ||
      stock.Symbol.toLowerCase().includes(term)
    );
  }
  onRowClick(stock:Stock){
    this.stockSelected.emit(stock)

  }
}
