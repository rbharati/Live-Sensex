import { Component, Input, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Stock } from '../../models/model';
import { MiniChartComponent } from "../mini-chart/mini-chart.component";

@Component({
  selector: 'app-stock-detail',
  standalone: true,
  imports: [CommonModule, MiniChartComponent],
  templateUrl: './stock-detail.component.html',
  styleUrl: './stock-detail.component.scss'
})
export class StockDetailComponent {

@Input() stock: Stock | null = null;

}
