import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { io, Socket } from 'socket.io-client';

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {
  private socket:Socket;

  constructor() {
    this.socket=io('http://127.0.0.1:5000/',{
      transports: ['websocket'],
      withCredentials: false
    })
   }
   

  

 listen(eventName: string): Observable<any> {
    return new Observable((subscriber) => {
      this.socket.on(eventName, (data) => {
        subscriber.next(data);
      });
      return () => this.socket.off(eventName);
    });
  }
  emit(eventName: string, data: any) {
    this.socket.emit(eventName, data);
  }
  disconnect() {
    this.socket.disconnect();
  }

}


