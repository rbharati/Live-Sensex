import { inject, Injectable } from '@angular/core';
import { Stock } from '../models/model';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServicesTsService {

  constructor() { }
  private http = inject(HttpClient)    // Inject HttpClient (Angular 17 way)
  private apiUrl = 'http://127.0.0.1:5000/stock';  // Your Python API

  getStocks(): Observable<Stock[]> {
    return this.http.get<Stock[]>(this.apiUrl); // Returns the stock data
  }
getStocks1(): Observable<Stock[]> {
    // const stocks: Stock[] = [
    //  {
    //   company: 'Apple Inc.',
    //   symbol: 'AAPL',
    //   price: 202.5,
    //   change: 0.5,
    //   marketCap: '3.18T',
    //   peRatio: '23.54',
    //   trend: [198, 200, 201, 203, 202.5],
    // },
    // {
    //   company: 'Microsoft Corp.',
    //   symbol: 'MSFT',
    //   price: 188.25,
    //   change: -1.2,
    //   marketCap: '2.84T',
    //   peRatio: '35.41',
    //   trend: [190, 189, 188, 187, 188.25],
    // },
    // {
    //   company: 'Amazon.com Inc.',
    //   symbol: 'AMZN',
    //   price: 2700.5,
    //   change: 0.3,
    //   marketCap: '1.41T',
    //   peRatio: '61.2',
    //   trend: [2675, 2680, 2690, 2700, 2700.5],
    // },
    // {
    //   company: 'Tesla Inc.',
    //   symbol: 'TSLA',
    //   price: 300.78,
    //   change: -0.18,
    //   marketCap: '900B',
    //   peRatio: '74.5',
    //   trend: [302, 301, 299, 300, 300.78],
    // },
    // {
    //   company: 'Alphabet Inc.',
    //   symbol: 'GOOGL',
    //   price: 188.21,
    //   change: 41.2,
    //   marketCap: '1.95T',
    //   peRatio: '27.9',
    //   trend: [140, 155, 160, 180, 188.21],
    // },
    // {
    //   company: 'NVIDIA Corp.',
    //   symbol: 'NVDA',
    //   price: 300.98,
    //   change: 36.7,
    //   marketCap: '2.3T',
    //   peRatio: '84.1',
    //   trend: [250, 275, 285, 295, 300.98],
    // },
    // {
    //   company: 'Meta Platforms Inc.',
    //   symbol: 'META',
    //   price: 1837.13,
    //   change: 30.74,
    //   marketCap: '1.28T',
    //   peRatio: '29.4',
    //   trend: [1700, 1750, 1780, 1800, 1837.13],
    // },
    // {
    //   company: 'Netflix Inc.',
    //   symbol: 'NFLX',
    //   price: 453.45,
    //   change: -1.75,
    //   marketCap: '205B',
    //   peRatio: '40.5',
    //   trend: [460, 458, 455, 452, 453.45],
    // },
    // {
    //   company: 'Adobe Inc.',
    //   symbol: 'ADBE',
    //   price: 612.22,
    //   change: 2.5,
    //   marketCap: '281B',
    //   peRatio: '42.6',
    //   trend: [590, 600, 605, 610, 612.22],
    // },
    // {
    //   company: 'Salesforce Inc.',
    //   symbol: 'CRM',
    //   price: 232.88,
    //   change: 1.8,
    //   marketCap: '240B',
    //   peRatio: '35.0',
    //   trend: [220, 225, 228, 231, 232.88],
    // },
    //   // Add more stocks similarly...
    // ];
     const stocks: Stock[] = [
    {
      "Change": -47.4,
      "ChangeP": "-3.21%",
      "Change_Numeric": -3.21,
      "Company": "Reliance Industries Limited",
      "Price": 1428.6,
      "Symbol": "RELIANCE.NS"
    },
    {
      "Change": -31.7,
      "ChangeP": "-0.99%",
      "Change_Numeric": -0.99,
      "Company": "Tata Consultancy Services Limited",
      "Price": 3158.2,
      "Symbol": "TCS.NS"
    },
    {
      "Change": 43.1,
      "ChangeP": "+2.2%",
      "Change_Numeric": 2.2,
      "Company": "HDFC Bank Limited",
      "Price": 2000.5,
      "Symbol": "HDFCBANK.NS"
    },
    {
      "Change": 40.0,
      "ChangeP": "+2.81%",
      "Change_Numeric": 2.81,
      "Company": "ICICI Bank Limited",
      "Price": 1465.8,
      "Symbol": "ICICIBANK.NS"
    },
    {
      "Change": -1.8,
      "ChangeP": "-0.11%",
      "Change_Numeric": -0.11,
      "Company": "Infosys Limited",
      "Price": 1584.3,
      "Symbol": "INFY.NS"
    },
    {
      "Change": 0.85,
      "ChangeP": "+0.1%",
      "Change_Numeric": 0.1,
      "Company": "State Bank of India",
      "Price": 824.2,
      "Symbol": "SBIN.NS"
    },
    {
      "Change": -14.0,
      "ChangeP": "-0.11%",
      "Change_Numeric": -0.11,
      "Company": "Maruti Suzuki India Limited",
      "Price": 12405.0,
      "Symbol": "MARUTI.NS"
    },
    {
      "Change": -6.0,
      "ChangeP": "-0.25%",
      "Change_Numeric": -0.25,
      "Company": "Asian Paints Limited",
      "Price": 2376.1,
      "Symbol": "ASIANPAINT.BO"
    },
    {
      "Change": 31.25,
      "ChangeP": "+0.92%",
      "Change_Numeric": 0.92,
      "Company": "Titan Company Limited",
      "Price": 3433.3,
      "Symbol": "TITAN.BO"
    },
    {
      "Change": 1.61,
      "ChangeP": "+0.71%",
      "Change_Numeric": 0.71,
      "Company": "Amazon.com, Inc.",
      "Price": 227.74,
      "Symbol": "AMZN"
    }
  ];
    return of(stocks);
  }
}
