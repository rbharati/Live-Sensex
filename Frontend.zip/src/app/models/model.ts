// export interface Stock {
//   company: string;   // e.g., Apple Inc.
//   symbol: string;    // e.g., AAPL
//   price: number;     // e.g., 202.50
//   change: number; 
//   trend?:number[]   // e.g., +0.5 or -1.2
//   marketCap?: string;     // New field
//   peRatio?: string;
// }
export  interface Stock {
   Company: string;
  Symbol: string;
  Price: number;
  Change: number;
  ChangeP: string;
  Change_Numeric: number;
}