import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SerachBarComponent } from "./components/serach-bar/serach-bar.component";
import { StockListComponent } from "./components/stock-list/stock-list.component";
import { StockDetailComponent } from "./components/stock-detail/stock-detail.component";
import { NavbarComponent } from "./components/navbar/navbar.component";
import { Stock } from './models/model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [StockListComponent, NavbarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  searchTerm=''
  selectedStock: Stock |null =null;


  onStockSelected(stock:Stock){
    this.selectedStock=stock
  }
    onSearchChanged(term: string) {
    this.searchTerm = term;
  }
  title = 'live-stocks-dashboard';
}
